from src.pkg import Project

project = Project(
    version="0.0.1",
    out=".build",
    cfg="cfg",
    bin="bin",
    packages=[
        "zsh",
        "git",
        "jq",
        "stow",
        "lua",
        "luarocks",
        "zip",
        "unzip",
        "ripgrep",
        "fd",
        "fzf",
        "atac",
        "ctop",
        "nvm@file",
        "omz@file",
    ],
)
