from pathlib import Path
from src.cli import Cli
from env import DOTFILES_CLI

if __name__ == "__main__":
    cli = Cli(Path.cwd() / DOTFILES_CLI)
    cli.run()
