import src.cli as cli

@cli.installer("zig")
def install(ctx: cli.Context) -> None:
    pass
