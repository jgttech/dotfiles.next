import src.cli as cli

@cli.installer("odin")
def install(ctx: cli.Context) -> None:
    pass
