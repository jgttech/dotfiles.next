import src.cli as cli

@cli.installer("typescript")
def install(ctx: cli.Context) -> None:
    pass
