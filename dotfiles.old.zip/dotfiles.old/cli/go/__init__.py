import src.cli as cli

@cli.installer("go")
def install(ctx: cli.Context) -> None:
    pass
