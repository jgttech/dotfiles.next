class Package:
    name: str

    def __init__(self, name: str) -> None:
        self.name = name
