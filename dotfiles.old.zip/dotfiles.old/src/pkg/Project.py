from dataclasses import dataclass

@dataclass
class Project:
    version: str
    out: str
    cfg: str
    bin: str
    packages: list[str]
