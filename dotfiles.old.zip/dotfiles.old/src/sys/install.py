from pathlib import Path
from src.ctx import Context

def install(ctx: Context) -> None:
    cfg = Path(ctx.build.cfg)
    bin = Path(ctx.build.bin)

    cfg.mkdir(parents=True, exist_ok=True)
    bin.mkdir(parents=True, exist_ok=True)

