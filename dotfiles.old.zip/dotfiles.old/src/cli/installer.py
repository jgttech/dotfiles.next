import click
from typing import Callable, TypeVar
from pathlib import Path
from os.path import join
from src.ctx import Context
from src.sys import install

T = TypeVar("T")

def installer(dir: str):
    cli = Path(join("cli", dir))
    ctx = Context(Path.cwd(), cli)

    install(ctx)

    def decoractor(fn: Callable[[Context], T]) -> Callable[[], T]:
        @click.command(cli.name)
        def wrapper() -> T:
            return fn(ctx)

        return wrapper
    return decoractor
